using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelManager : MonoBehaviour
{
    [Header("GUI Key Setting")]
    public KeyCode GUIKey;
    [Header("GUI Key Setting")]
    public bool AutoEnable;

    [Header("GUI Child Object Group")]
    [SerializeField]
    private GameObject GUIBackground;
    [SerializeField]
    private GameObject GUIButtonGroup;


    private bool GUIStatus = false;
    private GameObject GUIPanel;



    void Start()
    {
        GUIPanel = gameObject;
        if (AutoEnable) GUIStatus = AutoEnable;
        GUIBackground.SetActive(GUIStatus);

    }

    void Update()
    {
        if (Input.GetKeyDown(GUIKey))
        {
            GUIBackground.SetActive(!GUIStatus);
            GUIStatus = !GUIStatus;
        }
    }
    
    public void GUIToggle()
    {
        if (AutoEnable) return;
        GUIBackground.SetActive(!GUIStatus);
        GUIStatus = !GUIStatus;
    }
    public void GUIToggle(bool _status)
    {
        GUIBackground.SetActive(_status);
        GUIStatus = _status;
    }
    



}
